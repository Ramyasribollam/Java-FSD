/**
 * 
 */
/**
 * @author admin
 *
 */
module ArrayRotation {
}