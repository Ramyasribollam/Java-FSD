/**
 * 
 */
/**
 * @author admin
 *
 */
module RangeQueries {
}