/**
 * 
 */
/**
 * @author admin
 *
 */
module Queue {
}