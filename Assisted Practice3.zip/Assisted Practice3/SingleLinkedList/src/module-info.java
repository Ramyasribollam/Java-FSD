/**
 * 
 */
/**
 * @author admin
 *
 */
module SingleLinkedList {
}